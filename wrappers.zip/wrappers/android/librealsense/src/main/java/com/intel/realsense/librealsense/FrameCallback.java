package com.intel.realsense.librealsense;

public interface FrameCallback {
    void onFrame(Frame f);
}
