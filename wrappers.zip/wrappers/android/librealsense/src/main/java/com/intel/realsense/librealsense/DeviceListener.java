package com.intel.realsense.librealsense;

public interface DeviceListener {
    void onDeviceAttach();
    void onDeviceDetach();
}
