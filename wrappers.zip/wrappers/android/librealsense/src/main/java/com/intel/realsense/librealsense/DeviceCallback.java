package com.intel.realsense.librealsense;

public interface DeviceCallback {
    void onDevice(Device device);
}
