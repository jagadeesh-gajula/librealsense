package com.intel.realsense.librealsense;

import android.app.Activity;
import android.os.Bundle;

public class DeviceWatcherActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        finish();
    }
}
