package com.intel.realsense.librealsense;

public interface ProgressListener {
    void onProgress(float progress);
}
