package com.intel.realsense.camera;

public class PermissionsUtils {

    public static final int PERMISSIONS_REQUEST_CAMERA = 0;
    public static final int PERMISSIONS_REQUEST_READ = 1;
    public static final int PERMISSIONS_REQUEST_WRITE = 2;
    public static final int PERMISSIONS_REQUEST_ALL = 3;

}
