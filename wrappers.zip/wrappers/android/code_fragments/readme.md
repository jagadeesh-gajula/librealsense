# Android Wrapper Code Fragments

> In this folder, fragments of code have been added so that the user could know how to use the android API.
Please pay attention that these files cannot be ran and may not even compile.


