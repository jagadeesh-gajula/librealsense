#pragma once

#define RS2_PROJECT_POINT_TO_PIXEL 0x1000

struct Rs2PointPixel
{
	float point[3];
	float pixel[2];
};
