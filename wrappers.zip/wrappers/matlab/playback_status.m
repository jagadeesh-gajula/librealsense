classdef playback_status < int64
    enumeration
        unknown (0)
        playing (1)
        paused  (2)
        stopped (3)
        count   (4)
    end
end